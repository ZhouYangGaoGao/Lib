package cn.bingoogolapple.photopicker.util;

import androidx.core.content.FileProvider;

/**
 * @author Acheng
 * @Created on 2020/5/16.
 * @Email 345887272@qq.com
 * @Description 说明:
 */
public class CCRPhotoFileProvider extends FileProvider {
}
